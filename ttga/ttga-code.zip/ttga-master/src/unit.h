#ifndef UNIT_H
#define UNIT_H

/**
 * Empty type, to be used for template instantiation.
 */
struct unit {};

#endif // UNIT_H
